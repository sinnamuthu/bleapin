<?php
/*
Plugin Name: Lifestyle Social Media Buttons
Plugin URI: https://themeforest.net/item/the-lifestyle-elegant-and-simple-wordpress-blog-theme/19901575
Description: A simple plugin that enables you to add Share Buttons. Created for the Lifestyle theme.
Version: 1.0
Text Domain: lifestyle-social-media-buttons
Author: Nord Studio
Author URI: https://themeforest.net/user/nordstudio
License: GPL2
*/

/**
 * Enqueue public plugin styles.
 */ 
function lsmb_enqueue_scripts() {
  wp_register_style( 'lifestyle-social-media-buttons', plugin_dir_url( __FILE__ ) . 'assets/css/lifestyle-social-media-buttons.min.css', array(), '1.0' );

  if( ! wp_style_is( 'font-awesome', 'registered' ) )
    wp_register_style( 'font-awesome', plugin_dir_url( __FILE__ ) . 'assets/css/font-awesome.min.css', array(), '4.7.0' );

  wp_register_script( 'lifestyle-social-media-buttons-js', plugin_dir_url( __FILE__ ) . 'assets/js/public/lifestyle-social-media-buttons.min.js', array( 'jquery' ), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'lsmb_enqueue_scripts' );

function lsmb_load_plugin_textdomain() {
  load_plugin_textdomain( 'lsmb', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'lsmb_load_plugin_textdomain', 10 );

/**
 * Get HTML with post share buttons.
 *
 * @since 1.0
 */
function lsmb_get_share_buttons() {
  $post = get_post();

  if( ! $post )
    return;

  wp_enqueue_style( 'lifestyle-social-media-buttons' );
  wp_enqueue_style( 'font-awesome' );
  wp_enqueue_script( 'lifestyle-social-media-buttons-js' );

  $thumbnail_src = '';
  $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'post-thumbnail' );
  
  if( $thumbnail )
    $thumbnail_src = urlencode( esc_url( $thumbnail['0'] ) );

  $post_permalink = urlencode( esc_url( get_permalink( $post->ID ) ) );
  $title          = urlencode( strip_tags( get_the_title() ) );
  $excerpt        = urlencode( strip_tags( get_the_excerpt() ) );
  
  $buttons = array(
    'vk' => array(
      'url'    => 'http://vk.com/share.php?url=' . $post_permalink . '&amp;title=' . $title . '&amp;description=' . $excerpt . '&amp;image=' . $thumbnail_src,
      'title'  => esc_html__( 'Share on VK', 'lsmb' ),
      'icon'   => '<i class="fa fa-vk"></i>',
      'show'   => 0
     ),
    'facebook' => array(
      'url'    => 'http://www.facebook.com/sharer/sharer.php?u=' . $post_permalink,
      'title'  => esc_html__( 'Share on Facebook', 'lsmb' ),
      'icon'   => '<i class="fa fa-facebook"></i>',
      'show'   => 1
     ),
    'twitter' => array(
      'url'    => 'https://twitter.com/intent/tweet?text=' . $title . '&amp;url=' . $post_permalink,
      'title'  => esc_html__( 'Tweet It', 'lsmb' ),
      'icon'   => '<i class="fa fa-twitter"></i>',
      'show'   => 1
     ),
    'pinterest' => array(
      'text'   => esc_html__( 'Pin It', 'lsmb' ),
      'url'    => 'https://www.pinterest.com/pin/create/button/?description=' . $title . '&amp;media=' . $thumbnail_src . '&amp;url=' . $post_permalink,
      'title'  => esc_html__( 'Pin It', 'lsmb' ),
      'icon'   => '<i class="fa fa-pinterest"></i>',
      'show'   => 1
     ),
    'tumblr' => array(
      'url'    => 'http://www.tumblr.com/share/link?url=' . $post_permalink . '&amp;name=' . $title . '&amp;description=' . $excerpt,
      'title'  => esc_html__( 'Post on Tumblr', 'lsmb' ),
      'icon'   => '<i class="fa fa-tumblr"></i>',
      'show'   => 0
     ),
    'google' => array(
      'url'    => 'https://plus.google.com/share?url=' . $post_permalink,
      'title'  => esc_html__( 'Share on Google+', 'lsmb' ),
      'icon'   => '<i class="fa fa-google-plus"></i>',
      'show'   => 0
     ),
    'linkedin' => array(
      'url'    => 'https://www.linkedin.com/shareArticle?url=' . $post_permalink . '&amp;title=' . $title . '&amp;summary=' . $excerpt,
      'title'  => esc_html__( 'Share on LinkedIn', 'lsmb' ),
      'icon'   => '<i class="fa fa-linkedin"></i>',
      'show'   => 0
     )
  );
  
  $output = '';

  foreach( $buttons as $button_id => $button_data ) {
    if( get_theme_mod( 'lsmb_display_' . $button_id . '_share_button', $button_data['show'] ) ) {
      $output .= sprintf( '<a href="%s" title="%s" class="lsmb-share-button lsmb-%s-share-button" rel="nofollow">%s</a>', esc_url( $button_data['url'] ), esc_attr( $button_data['title'] ), esc_attr( $button_id ), $button_data['icon'] );
    }
  } 
  
  if( $output )
    return sprintf( '<div class="lsmb-share-buttons">%s</div>', $output );
}

/**
 * Implement Customizer additions and adjustments.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function lsmb_customize_register( $wp_customize ) {
  // Share Buttons
  $wp_customize->add_panel( 'lifestyle-social-media-buttons', array(
    'title' => esc_html__( 'Share Buttons', 'lsmb' ),
  ) ); 

  // Share Buttons - Display Options
  $wp_customize->add_section( 'lifestyle-social-media-buttons-display-options',
    array(
      'title' => esc_html__( 'Display Options', 'lsmb' ),
      'panel' => 'lifestyle-social-media-buttons'
    )
  ); 
  
  $wp_customize->add_setting( 'display_facebook_share_button',
    array(
      'default' => 1,
      'sanitize_callback' => 'lsmb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'lsmb_display_facebook_share_button', array(
    'type'     => 'checkbox',
    'priority' => 0,
    'label'    => esc_html__( 'Facebook', 'lsmb' ),
    'section'  => 'lifestyle-social-media-buttons-display-options',
  ) );
  
  $wp_customize->add_setting( 'lsmb_display_twitter_share_button',
    array(
      'default' => 1,
      'sanitize_callback' => 'lsmb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'lsmb_display_twitter_share_button', array(
    'type'     => 'checkbox',
    'priority' => 5,
    'label'    => esc_html__( 'Twitter', 'lsmb' ),
    'section'  => 'lifestyle-social-media-buttons-display-options',
  ) );
  
  $wp_customize->add_setting( 'lsmb_display_google_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'lsmb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'lsmb_display_google_share_button', array(
    'type'     => 'checkbox',
    'priority' => 10,
    'label'    => esc_html__( 'Google Plus', 'lsmb' ),
    'section'  => 'lifestyle-social-media-buttons-display-options',
  ) );
  
  $wp_customize->add_setting( 'lsmb_display_pinterest_share_button',
    array(
      'default' => 1,
      'sanitize_callback' => 'lsmb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'lsmb_display_pinterest_share_button', array(
    'type'     => 'checkbox',
    'priority' => 15,
    'label'    => esc_html__( 'Pinterest', 'lsmb' ),
    'section'  => 'lifestyle-social-media-buttons-display-options',
  ) );
  
  $wp_customize->add_setting( 'lsmb_display_tumblr_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'lsmb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'lsmb_display_tumblr_share_button', array(
    'type'     => 'checkbox',
    'priority' => 15,
    'label'    => esc_html__( 'Tumblr', 'lsmb' ),
    'section'  => 'lifestyle-social-media-buttons-display-options',
  ) );
  
  $wp_customize->add_setting( 'lsmb_display_linkedin_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'lsmb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'lsmb_display_linkedin_share_button', array(
    'type'     => 'checkbox',
    'priority' => 20,
    'label'    => esc_html__( 'LinkedIn', 'lsmb' ),
    'section'  => 'lifestyle-social-media-buttons-display-options',
  ) );

  $wp_customize->add_setting( 'lsmb_display_vk_share_button',
    array(
      'default' => 0,
      'sanitize_callback' => 'lsmb_checkbox_sanitize',
    )
  );
  
  $wp_customize->add_control( 'lsmb_display_vk_share_button', array(
    'type'     => 'checkbox',
    'priority' => 25,
    'label'    => esc_html__( 'VK', 'lsmb' ),
    'section'  => 'lifestyle-social-media-buttons-display-options',
  ) );
}

add_action( 'customize_register', 'lsmb_customize_register' );

/**
 * Sanitization callback for checkbox.
 */
function lsmb_checkbox_sanitize( $value ) {
  if ( $value == 1 ) {
      return 1;
  } else {
      return '';
  }
}
?>
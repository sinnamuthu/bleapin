=== Lifestyle Social Media Buttons ===
Tags: share, buttons, social, follow
Requires at least: 5.1
Tested up to: 5.1
Stable tag: 1.0.0
License: GPLv2 or later
Author URI: https://themeforest.net/user/nordstudio

== Description ==

A simple plugin that enables you to add Share and Follow buttons. Created for the Lifestyle theme.

== Installation ==

Just install and activate.

== Changelog ==

= 0.1 =

* Initial release

=== Nord Recent Posts Widget ===
Tags: widget, recent posts, thumbnails
Requires at least: 3.7
Tested up to: 5.0.0
Stable tag: 1.0.0
License: GPLv2 or later
Author URI: https://themeforest.net/user/nordstudio

== Description ==

A WordPress widget for showing your latest blog posts with thumbnails.

== Installation ==

Just install and activate.

== Changelog ==

= 0.1 =

* Initial release

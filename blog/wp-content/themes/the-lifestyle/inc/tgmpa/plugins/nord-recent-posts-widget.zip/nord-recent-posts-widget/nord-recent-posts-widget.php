<?php
/*
Plugin Name: Nord Recent Posts Widget
Plugin URI: https://themeforest.net/user/nordstudio/portfolio
Description: A WordPress widget for showing your latest blog posts with thumbnails.
Version: 1.1
Text Domain: nord-recent-posts-widget
Author: Nord Studio
Author URI: https://themeforest.net/user/nordstudio
License: GPL2
*/

// Register the widget
function nord_recent_posts_widget_init() {
  register_widget( 'Nord_Recent_Posts_Widget' );
}
add_action( 'widgets_init', 'nord_recent_posts_widget_init' );

function nrpw_load_plugin_textdomain() {
  load_plugin_textdomain( 'nord-recent-posts-widget', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'nrpw_load_plugin_textdomain', 10 );

/**
 * Nord_Recent_Posts widget class
 *
 * @since 1.0
 */
class Nord_Recent_Posts_Widget extends WP_Widget {

	private $orderby;
	
	/**
	 * Constructor.
	 */
	public function __construct() {
	
		parent::__construct( 'nord-widget-recent-posts', esc_html__( 'Nord Recent Posts', 'nord-recent-posts-widget' ), array(
			'classname'   => 'nord-widget-recent-posts',
			'description' => esc_html__( 'Use this widget to list your recent posts.', 'nord-recent-posts-widget' ),
		) );

    $this->orderby = array(
     'date'         => esc_html__( 'date', 'nord-recent-posts-widget' ), 
     'comments_num' => esc_html__( 'number of comments', 'nord-recent-posts-widget' ),
     'random'       => esc_html__( 'random', 'nord-recent-posts-widget' )
    );
    
    add_action( 'wp_enqueue_scripts', array( $this, 'public_enqueue_styles' ) );
	}

  /**
   * Enqueue public widget styles.
   *
   * @access public
   */ 
  public function public_enqueue_styles() {
    wp_register_style( 'nord-recent-posts-widget-css', plugin_dir_url( __FILE__ ) . 'assets/css/public/nord-recent-posts-widget.min.css', array(), '1.0' );
  }

	/**
	 * Output the HTML for this widget.
	 *
	 * @access public
	 *
	 * @param array $args     An array of standard parameters for widgets in this theme.
	 * @param array $instance An array of settings for this widget instance.
	 */
	public function widget( $args, $instance ) {
	
		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		$title = ( ! empty( $instance['title'] ) ) ? strip_tags( $instance['title'] ) : esc_html__( 'Recent Posts', 'nord-recent-posts-widget' );
	
		$query_args = array(
		  'order'          => 'DESC',
			'posts_per_page' => $number,
			'no_found_rows'  => true,
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'post__not_in'   => get_option( 'sticky_posts' )
		);
		
    $query_args['tax_query'] = array();
    
    if( ! empty( $instance['category'] ) ){
      $query_args['tax_query'][] = array(
          'taxonomy' => 'category',
          'terms'    => absint( $instance['category'] ),
          'field'    => 'term_id'
      );
		}
		
		if( ! empty( $instance['tags'] ) ) {
      $tags = explode( ',', $instance['tags'] );
      $query_args['tax_query'][] = array(
          'taxonomy' => 'post_tag',
          'terms'    => $tags,
          'field'    => 'name'
      );
		}

    if( count( $query_args['tax_query'] ) > 1 ){
      $query_args['tax_query']['relation'] = 'AND';
    }

		$orderby = isset( $instance['orderby'] ) ? $instance['orderby'] : 'date';
		
		switch ($orderby) {
      case 'comments_num':
        $query_args['orderby'] = 'comment_count';
        break;
      case 'random':
        $query_args['orderby'] = 'rand';
        break;
		}

		$recent_posts = new WP_Query( $query_args );

		if ( $recent_posts->have_posts() ) :
      wp_enqueue_style( 'nord-recent-posts-widget-css' );

      $show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

			echo $args['before_widget'];
	    
			if ( ! empty( $title ) ) {
        printf( '%s%s%s', $args['before_title'], $title, $args['after_title'] );
      } 
		?>
			
		<ul>
      <?php while ( $recent_posts->have_posts() ) : $recent_posts->the_post(); ?>
      
    	<li class="nrwp-post">
        <?php if ( has_post_thumbnail() ) : ?>
        <div class="nrpw-post-thumbnail">
          <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'thumbnail' ); ?></a>
        </div>
        <?php endif; ?>
        
        <div class="nrpw-post-content">
          <?php 
            if( ! get_the_title() ) {
              $format = get_post_format();
              $default_title = ( ! $format || $format == 'standard' ) ? esc_html__( 'Untitled Post', 'nord-recent-posts-widget' ) : get_post_format_string( $format );
            }
          ?>
          <a href="<?php the_permalink(); ?>"><?php get_the_title() ? the_title() : printf( $default_title ); ?></a>
          <?php 
            if( $show_date ) {
              printf( '<span class="nrpw-post-date">%s</span>', get_the_date() );
            } 
          ?>
        </div>
			</li>  
      <?php endwhile; ?>
		</ul>	
			
	  <?php
			echo $args['after_widget'];

			// Reset the post globals as this query will have stomped on it.
			wp_reset_postdata();
		endif;
	}
	
	/**
	 * Deal with the settings when they are saved by the admin.
	 *
	 * Here is where any validation should happen.
	 *
	 * @param array $new_instance New widget instance.
	 * @param array $instance     Original widget instance.
	 * @return array Updated widget instance.
	 */
	function update( $new_instance, $instance ) {
    $instance['title']  = strip_tags( $new_instance['title'] );
    $instance['number'] = ( !empty( $new_instance['number'] ) ) ? absint( $new_instance['number'] ) : 5;
    
    if( array_key_exists( $new_instance['orderby'], $this->orderby ) ){
      $instance['orderby'] = $new_instance['orderby'];
    }

		$instance['category']   = isset( $new_instance['category'] ) ? absint( $new_instance['category'] ) : 0;
		$instance['tags']       = strip_tags( $new_instance['tags'] );
		$instance['show_date']  = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
    return $instance;
	}
	
	/**
	 * Display the form for this widget on the Widgets page of the Admin area.
	 *
	 * @param array $instance
	 */
	function form( $instance ) {
    $instance = wp_parse_args( (array) $instance, array( 
      'title'      => '', 
      'number'     => 5, 
      'orderby'    => 'date',
      'category'   => 0,
      'tags'       => '',
      'show_date'  => true
    ) );
	?>
		
    <p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'nord-recent-posts-widget' ); ?></label>
    <input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>"></p>

    <p><label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'nord-recent-posts-widget' ); ?></label>
    <input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo absint( $instance['number'] ); ?>" size="3"></p>

    <p>
      <label for="<?php echo esc_attr( $this->get_field_id( 'orderby' ) ); ?>"><?php esc_html_e( 'Order by:', 'nord-recent-posts-widget' ); ?></label>
      <select id="<?php echo esc_attr( $this->get_field_id( 'orderby' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'orderby' ) ); ?>">
        <?php foreach ( $this->orderby as $slug => $name ) : ?>
        <option value="<?php echo esc_attr( $slug ); ?>"<?php selected( $instance['orderby'], $slug ); ?>><?php echo esc_attr( $name ); ?></option>
        <?php endforeach; ?>
      </select>
    </p>
    
    <p>
      <label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>"><?php esc_html_e( 'Category:', 'nord-recent-posts-widget' ); ?></label>
      <?php
        wp_dropdown_categories( array(
          'show_option_all' => esc_html__( 'All Categories', 'nord-recent-posts-widget' ),
          'selected'        => absint( $instance['category'] ),
          'name'            => esc_attr( $this->get_field_name( 'category' ) ),
          'id'              => esc_attr( $this->get_field_id( 'category' ) ),
          'class'           => 'widefat'
        ) );
      ?>
    </p>
    
    <p><label for="<?php echo esc_attr( $this->get_field_id( 'tags' ) ); ?>"><?php esc_html_e( 'Tags (separated by commas):', 'nord-recent-posts-widget' ); ?></label>
    <input id="<?php echo esc_attr( $this->get_field_id( 'tags' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'tags' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['tags'] ); ?>"></p>
    
    <p><input class="checkbox" type="checkbox" <?php checked( $instance['show_date'] ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_date' ) ); ?>" />
		<label for="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>"><?php esc_html_e( 'Display post date?', 'nord-recent-posts-widget' ); ?></label></p>
		
  <?php
	}
}
?>
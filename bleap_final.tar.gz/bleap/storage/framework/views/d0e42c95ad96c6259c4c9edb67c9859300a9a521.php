Name: <?php echo e($formData['name']); ?> <br/>
Phone: <?php echo e($formData['phone']); ?> <br/>
Email: <?php echo e($formData['email']); ?> <br/>
City: <?php echo e($formData['city']); ?> <br/>
Message: <?php echo e($formData['message']); ?> <br/>
Intereseted in: 
	<?php if($formData['responsive']): ?>
		Responsive Website Design & Development <br/>
	<?php endif; ?>
	<?php if($formData['eCommerce']): ?>
		e-Commerce Solutions(Shopify, Magento, Woocommerce) <br/>
	<?php endif; ?>
	<?php if($formData['digitalMarketing']): ?>
		Digital Marketing <br/>
	<?php endif; ?>
	<?php if($formData['socialMedia']): ?>
		Social Media Marketing <br/>
	<?php endif; ?>
	<?php if($formData['seo']): ?>
		Search Engine Optimization(SEO) <br/>
	<?php endif; ?>
	<?php if($formData['goodleAds']): ?>
		Search Engine Marketing(Google Ads) <br/>
	<?php endif; ?>
	<?php if($formData['videoContent']): ?>
		Video Content Development <br/>
	<?php endif; ?>
	<?php if($formData['strategic']): ?>	
		Strategic Marketing <br/>
	<?php endif; ?><?php /**PATH /var/www/html/bleap/resources/views/mails/contact.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Bleap</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/home/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/home/css/bleap-styles.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/home/css/custom.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/home/css/bleap-responsive.css')); ?>">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('public/home/images/favicon.png')); ?>"/>
        <script language="javascript" type="text/javascript" src="<?php echo e(asset('public/home/js/jquery-3.4.1.min.js')); ?>"></script>
        
        <!-- Styles -->
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-101433712-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-101433712-1');
        </script>
    </head>
    <body>
        <section class="wrapper">
            

            <div id="root"></div>
        </section>
        <script src="<?php echo e(url('public/js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /var/www/html/bleap/resources/views/welcome.blade.php ENDPATH**/ ?>
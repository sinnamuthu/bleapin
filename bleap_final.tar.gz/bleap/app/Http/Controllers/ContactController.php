<?php

namespace App\Http\Controllers;

use App\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendContactMail;
use App\Subscriber;
use App\Mail\SubscriberWelcome;

class ContactController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /*$request->validate([
            'name' => ,
            'phone' => ,
            'email' => ,
            'city' => ,
            'interest' => ,
            'message' => ,
        ]);*/
        $contact = ['name' => $request->get('name'), 
                    'phone' => $request->get('phone'), 
                    'email' => $request->get('email'), 
                    'city' => $request->get('city'), 
                    'responsive' => in_array('responsive', $request->interest) ? 1 : 0, 
                    'eCommerce' => in_array('eCommerce', $request->interest) ? 1 : 0, 
                    'digitalMarketing' => in_array('digitalMarketing', $request->interest) ? 1 : 0, 
                    'socialMedia' => in_array('socialMedia', $request->interest) ? 1 : 0, 
                    'seo' => in_array('seo', $request->interest) ? 1 : 0, 
                    'goodleAds' => in_array('goodleAds', $request->interest) ? 1 : 0, 
                    'videoContent' => in_array('videoContent', $request->interest) ? 1 : 0, 
                    'strategic' => in_array('strategic', $request->interest) ? 1 : 0,
                    'message' => $request->get('message', $request->interest)
                ];
        $status = Contact::create($contact);
        if ($status) {
            Mail::to('bleap@yopmail.com')->send(new SendContactMail($contact));
            return ['status' => true];
        }
        return ['status' => false];
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function show(Contact $contact)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function edit(Contact $contact)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Contact $contact)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function destroy(Contact $contact)
    {
        //
    }

    public function joinUs(Request $request)
    {
        $request->validate([
            'email' => 'email | unique:subscribers'
        ]);
        $status = Subscriber::create([
            'email' => $request->email
        ]);       
        if ($status) {
            Mail::to($request->email)->send(new SubscriberWelcome());
        }
        return ['status' => true];
    }
}

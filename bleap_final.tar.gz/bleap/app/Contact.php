<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    protected $fillable = [ 'name', 'phone', 'email', 'city', 'responsive', 
    						'eCommerce', 'digitalMarketing', 'socialMedia', 'seo', 'goodleAds', 'videoContent', 'strategic', 'message' 
    					];
}

<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Bleap</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="{{ asset('public/home/css/bootstrap.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('public/home/css/bleap-styles.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('public/home/css/custom.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('public/home/css/bleap-responsive.css') }}">
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('public/home/images/favicon.png') }}"/>
        <script language="javascript" type="text/javascript" src="{{ asset('public/home/js/jquery-3.4.1.min.js') }}"></script>{{-- 
        <script language="javascript" type="text/javascript" src="{{ asset('public/home/js/bootstrap-select.js') }}"></script> --}}
        {{-- <script language="javascript" type="text/javascript" src="{{ asset('public/home/js/bootstrap.min.js') }}"></script> --}}
        <!-- Styles -->
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-101433712-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-101433712-1');
        </script>
    </head>
    <body>
        <section class="wrapper">
            {{-- @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif --}}

            <div id="root"></div>
        </section>
        <script src="{{ url('public/js/app.js') }}"></script>
    </body>
</html>

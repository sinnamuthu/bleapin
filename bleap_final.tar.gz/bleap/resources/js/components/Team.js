import React, { Component } from 'react';
import config from './Config';
import Footer from './layout/Footer';
import MetaTags from 'react-meta-tags';

class Team extends Component {
    render() {
        return (
            <React.Fragment>
                    <MetaTags>
                        
                    </MetaTags>
                    <section className="sub-page team section-wrap-btm">
                        <section className="container">
                        <section className="hdg">
							<h1 className="text-center">Our Team</h1>
						</section>
							<ul>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/neeraj.jpg"} alt="" className="img-responsive" /></figure>
									<p>Neeraj</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/neelu.jpg"} alt="" className="img-responsive" /></figure>
									<p>Neelu</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/saravanan.jpg"} alt="" className="img-responsive" /></figure>
									<p>Saravanan</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/giri.jpg"} alt="" className="img-responsive" /></figure>
									<p>Giri</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/anuradha.jpg"} alt="" className="img-responsive" /></figure>
									<p>Anuradha</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/subhasis.jpg"} alt="" className="img-responsive" /></figure>
									<p>Subhasis</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/eshwar.jpg"} alt="" className="img-responsive" /></figure>
									<p>Eshwar</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/sathya.jpg"} alt="" className="img-responsive" /></figure>
									<p>Sathya</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/karthikeyan.jpg"} alt="" className="img-responsive" /></figure>
									<p>Karthikeyan</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/bairavan.jpg"} alt="" className="img-responsive" /></figure>
									<p>Bairavan</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/yeshwant.jpg"} alt="" className="img-responsive" /></figure>
									<p>Yeshwant</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/naseera.jpg"} alt="" className="img-responsive" /></figure>
									<p>Naseera</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/madhuvanthi.jpg"} alt="" className="img-responsive" /></figure>
									<p>Madhuvanthi</p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/kristen.jpg"} alt="" className="img-responsive" /></figure>
									<p>Kristen Jude </p>						
								</li>
								<li>
							     <figure><img src={config.ROUTE_URL+"/public/home/images/team/govind.jpg"} alt="" className="img-responsive" /></figure>
									<p>Govind</p>						
								</li>
						</ul>

                    </section>
                    </section>
                 <Footer />
            </React.Fragment>
        );
    }
}
export default Team;

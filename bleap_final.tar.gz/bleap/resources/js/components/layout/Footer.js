import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import config from '.././Config';

class Footer extends Component {
	constructor(props) {
		super(props);
		this.state = {
           
        };
	}

	componentDidMount() {
	}

	render() {
		return (
			<footer>
				<section className="footer">
					<section className="ftr-top">
						<section className="container">
							<section className="row">
								<section className="col-lg-3 col-sm-6">
									<h3>Quick Links</h3>
										<ul>
											<li><Link to={config.ROUTE_URL+'/about-us'}>About us</Link></li>
											<li><Link to={config.ROUTE_URL+'/services'}>Services</Link></li>
											<li><Link to={config.ROUTE_URL+'/portfolio'}>Our Work</Link></li>
											<li><Link to={config.ROUTE_URL+'/blog'}>Blog</Link></li>
											<li><Link to={config.ROUTE_URL+'/careers'}>Careers</Link></li>
											<li><Link to={config.ROUTE_URL+'/contact-us'}>Contact Us</Link></li>
											<li><Link to={config.ROUTE_URL+'/privacy-policy'}>Privacy policy</Link></li>
										</ul>
								</section>
								<section className="col-lg-3 col-sm-6">
									<h3>Services</h3>
										<ul>
											<li><Link to={config.ROUTE_URL+'/services/responsive-website-design-development'}>Responsive Web site Design & Development</Link></li>
											<li><Link to={config.ROUTE_URL+'/services/search-engine-optimization'}>Search Engine Optimization</Link></li>
											<li><Link to={config.ROUTE_URL+'/services/online-advertising'}>Online Advertising</Link></li>
											<li><Link to={config.ROUTE_URL+'/services/strategic-marketing'}>Strategic Marketing</Link></li>
											<li><Link to={config.ROUTE_URL+'/services/ecommerce-solutions'}>Ecommerce Solutions</Link></li>
										</ul>
								</section>
								<section className="col-lg-3 col-sm-6">
									<h3>Contact Us</h3>
										<ul>
											<li><Link to={config.ROUTE_URL+'/contact-us/digital-marketing-agency-in-chennai'}>Chennai</Link></li>
											<li><Link to={config.ROUTE_URL+'/contact-us/digital-marketing-agency-in-mumbai'}>Mumbai</Link></li>
											<li><Link to={config.ROUTE_URL+'/contact-us/digital-marketing-agency-in-pune'}>Pune</Link></li>
											<li><Link to={config.ROUTE_URL+'/contact-us/digital-marketing-agency-in-bangalore'}>Bangalore</Link></li>
										</ul>
								</section>
								<section className="col-lg-3 col-sm-6">
									<h3>Social Media</h3>
										<ul className="social clearfix">
											<li className="fb"><a href="https://www.facebook.com/bleap.in/" target="_blank">Facebook</a></li>
											<li className="twitter"><a href="javascript:;">twitter</a></li>
											<li className="linked"><a href="https://www.linkedin.com/company/bleap/" target="_blank">linkedin</a></li>
											<li className="instagram"><a href="https://www.instagram.com/bleap.in/" target="_blank">instagram</a></li>
										</ul>
								</section>
							</section>
						</section>
					</section>
					<section className="ftr-btm">
						<section className="container">
							<h3>Get in touch</h3>
							<section className="row">
								<section className="col-lg-3 col-sm-6">
									<section className="ftr-add">									
										<h4>Chennai</h4>
										<p>1st floor, 95, Poes Main Road, Teynampet, Chennai - 600 018, Tamil Nadu, India</p>
										<p className="ph"><a href="tel:919382809420">+91 93828 09420</a><br /><a href="tel:04448545327">+91 44 4854 5327</a></p>
									</section>
								</section>
								<section className="col-lg-3 col-sm-6">
									<section className="ftr-add">				
										<h4>Mumbai</h4>
										<p>9, Prem Kiran, Plot 195 Sher-e-Punjab CHS, Mahakali Caves Rd, Andheri East, Mumbai - 400 093, Maharashtra, India</p>
										<p className="ph"><a href="tel:919382809420">+91 93828 09420</a><br /><a href="tel:04448545327">+91 44 4854 5327</a></p>
									</section>
								</section>
								<section className="col-lg-3 col-sm-6">
									<section className="ftr-add">				
										<h4>Pune</h4>
										<p>B2/7, Tridal Nagar, Shastri Nagar, Yerwada, Pune - 411 006, Maharashtra, India</p>
										<p className="ph"><a href="tel:919820332354">+91 98203 32354</a><br /><a href="tel:04448545327">+91 44 4854 5327</a></p>
									</section>
								</section>
								<section className="col-lg-3 col-sm-6">
									<section className="ftr-add">				
										<h4>Bangalore</h4>
										<p>Flat 806, GK Meadows, Shikari Palya Main Road, Electronic City Phase -1. Bangalore - 560 105, Karnataka, India</p>
										<p className="ph"><a href="tel:919663465465">+91 96634 65465</a><br /><a href="tel:04448545327">+91 44 4854 5327</a></p>
									</section>
								</section>
							</section>
						</section>
					</section>
				</section>
				<section className="copyright">
					<section className="container pos-rel">				
						<p>&copy; 2019 Bleap All Right Reserved</p>
						<aside className="google-partner">
							<a href="https://www.google.com/partners/agency?id=2495672630" target="_blank">
							<img src={config.ROUTE_URL+"/public/home/images/google-batch.jpg"} alt="Google partner" className="img-responsive" /></a>
						</aside>
					</section>
				</section>
			</footer>
		);
	}
}

export default Footer;
const CONFIG = {
  APP_URL: 'http://'+window.location.hostname,
  ROUTE_URL: '/bleap'
}

export default CONFIG;
import React, {Component} from 'react';
import config from './Config';
import Footer from './layout/Footer';
import MetaTags from 'react-meta-tags';

class Portfolio extends Component{
    render() {
        return (
            <React.Fragment>
                <MetaTags>
                    <title>Our Work - BLeap</title>
                    <meta name="description" content="Want to learn how Bleap has helped its clients grow their busines profitably online. Read our case studies in Responsive Web Design &amp; Development, SEO, PPC, Social Media Marketing, Ecommerce Solutions and Strategic Marketing."/>
                    <link rel="canonical" href="https://www.bleap.in/our-work/" />
                    <meta property="og:locale" content="en_US" />
                    <meta property="og:type" content="article" />
                    <meta property="og:title" content="Our Work - BLeap" />
                    <meta property="og:description" content="Want to learn how Bleap has helped its clients grow their busines profitably online. Read our case studies in Responsive Web Design &amp; Development, SEO, PPC, Social Media Marketing, Ecommerce Solutions and Strategic Marketing." />
                    <meta property="og:url" content="https://www.bleap.in/our-work/" />
                    <meta property="og:site_name" content="BLeap" />
                    <meta property="og:image" content="http://bleap.in/wp-content/uploads/2018/08/indus-valley.jpg" />
                    <meta name="twitter:card" content="summary_large_image" />
                    <meta name="twitter:description" content="Want to learn how Bleap has helped its clients grow their busines profitably online. Read our case studies in Responsive Web Design &amp; Development, SEO, PPC, Social Media Marketing, Ecommerce Solutions and Strategic Marketing." />
                    <meta name="twitter:title" content="Our Work - BLeap" />
                    <meta name="twitter:image" content="http://bleap.in/wp-content/uploads/2018/08/indus-valley.jpg" />
                </MetaTags>
                    <section className="sub-page portfolio section-wrap">
                        <section className="container">
	                    	<section className="hdg">					
								<h1>Building exciting customer experiences</h1>
							</section>
                            <section className="row">
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/indus-valley.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/indus-valley.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Online Advertising <span>The Indus Valley</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/spr.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/spr.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Online Advertising <span>SPR</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/rane-foundation.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/rane-foundation.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Responsive Webdesign <span>Rane Foundation</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/rockNshop.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/rockNshop.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Search Engine Optimization <span>Rock N Shop</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/chola.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/chola.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Strategic Marketing <span>Chola MS</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/done.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/done.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Search Engine Optimization <span>Done &amp; Partners</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/globeHealer.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/globeHealer.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Online Advertising <span>Globe Healer</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/idbi.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/idbi.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Online Advertising <span>IDBI Life Insurance</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/kriyaTec.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/kriyaTec.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Search Engine Optimization <span>KriyaTec</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/motorZo.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/motorZo.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Online Advertising <span>Motorzo</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/nhrd.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/nhrd.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Strategic Marketing <span>NHRD</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/rane-group.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/rane-group.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Strategic Marketing <span>Rane Group</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/talkPro.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/talkPro.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Display Advertising <span>TalkPro</span></p>
    							        </div>
    							    </a>
    							</div>
    							<div className="cl works-item ImageWrapper zoom" >
        							<img data-no-retina="" alt="" title="" className="img-responsive" src={config.ROUTE_URL+"/public/home/images/portfolio/tmb/avante.jpg"} />
        							<a className="venobox vbox-item" data-gall="portfolio-gallery" target="_blank" href={config.ROUTE_URL+"/public/home/images/portfolio/big/avante.jpg"}>
    							        <div className="ImageOverlayCl">
    							            <p className="valign text-center">Online Advertising <span>Avante Immigration</span></p>
    							        </div>
    							    </a>
    							</div>



                            </section>
                        </section>
                    </section>
			 <Footer />
            </React.Fragment>
        );
    }
}

export default Portfolio;

import React, { Component } from 'react';
import config from './Config';
import Footer from './layout/Footer';
import MetaTags from 'react-meta-tags';

class About extends Component {
    render() {
        return (
        	<React.Fragment>
        		<MetaTags>
        			<title>Online Marketing | SEO | Social Media | Analytics Chennai, India</title>
        			<meta name="description" content="Bleap is an award winning, leading digital marketing company, offering digital marketing solutions for B2B, B2C &amp; eCommerce companies. Our digital marketing services include responsive web development, SEO, PPC, Social Media Marketing and Branding"/>
					<link rel="canonical" href="https://www.bleap.in/about-us/" />
					<meta property="og:locale" content="en_US" />
					<meta property="og:type" content="article" />
					<meta property="og:title" content="Online Marketing | SEO | Social Media | Analytics Chennai, India" />
					<meta property="og:description" content="Bleap is an award winning, leading digital marketing company, offering digital marketing solutions for B2B, B2C &amp; eCommerce companies. Our digital marketing services include responsive web development, SEO, PPC, Social Media Marketing and Branding" />
					<meta property="og:url" content="https://www.bleap.in/about-us/" />
					<meta property="og:site_name" content="BLeap" />
					<meta property="og:image" content="http://bleap.in/wp-content/uploads/2018/07/about-us.jpg" />
					<meta name="twitter:card" content="summary_large_image" />
					<meta name="twitter:description" content="Bleap is an award winning, leading digital marketing company, offering digital marketing solutions for B2B, B2C &amp; eCommerce companies. Our digital marketing services include responsive web development, SEO, PPC, Social Media Marketing and Branding" />
					<meta name="twitter:title" content="Online Marketing | SEO | Social Media | Analytics Chennai, India" />
					<meta name="twitter:image" content="http://bleap.in/wp-content/uploads/2018/07/about-us.jpg" />
        		</MetaTags>
	            <section className="sub-page about">
	             	<section className="intro section-wrap">
                    	<section className="container">
							<aside className="item-img">
                            	<h2>BLeap</h2>
	                            <h3>Website Design & Digital Marketing Company Chennai, Mumbai, Pune & Bangalore</h3>
                                <figure><img src={config.ROUTE_URL+"/public/home/images/aboutus.jpg"} alt="About us" className="img-responsive" /></figure>
							</aside>	
                        	<aside className="cnt">
                            	<h2>BLeap</h2>
	                            <h3>Website Design & Digital Marketing Company Chennai, Mumbai, Pune & Bangalore</h3>
	                            <p>Established in 2016, Bleap Integrated Business Solutions is a full service digital marketing agency with offices located in Chennai and New Delhi. We provide Online services such as, Responsive Web Design & Development, Search Engine Optimization (SEO), Search Engine Marketing (SEM), Social Media Marketing (SMM) and Strategic Marketing Services to clients from India and across the world.</p>
								<p>We have a team of experts comprising of Project Managers, Web Designers, Developers, SEO Experts, and Search & Social Media Marketers with over 5 decades of combined experience across variety of businesses. Today we boast of a unique, close-knit team with experts in all facets of digital marketing committed to grow your business.</p>
	                        	<h4>We follow a simple work philosophy:</h4>
									<ul>
										<li>Think Big - Start Small - Scale Fast</li>
										<li>Highest Standards of Quality</li>
										<li>Personalized Attention</li>
										<li>Results focused Innovation</li>
										<li>Exceeding Client Expectations</li>
									</ul>
                        	</aside>
                    	</section>
                    	<section className="btm-bg btm-img"></section>
                	</section>
                </section>
			 <Footer />
	        </React.Fragment>
        );
    }
}
export default About;
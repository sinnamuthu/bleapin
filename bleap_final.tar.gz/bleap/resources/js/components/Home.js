import React, { Component } from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import config from './Config';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import validator from 'validator';
import Select from 'react-select';
import Footer from './layout/Footer';
import $ from 'jquery';
import { Link } from 'react-router-dom';
import MetaTags from 'react-meta-tags';

class Home extends Component {
    
    constructor(props){
        super(props);
        this.state = {
            name: '',
            nameErr: '',
            phone: '',
            phoneErr: '',
            email: '',
            emailErr: '',
            city: '',
            cityErr: '',
            message: '',
            messageErr: '',
            formInvalid: false,
            interest: [],
            interestErr: '',
            modalemail: '',
            modalemailErr: '',
        };
        this.validateForm = this.validateForm.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.modalValidateForm = this.modalValidateForm.bind(this);
        this.modalHandleSubmit = this.modalHandleSubmit.bind(this);
        this.interestChange = this.interestChange.bind(this);
        toast.configure();
        // document.title = 'Home';
    }

    componentDidMount(){
        if (!localStorage.getItem('modelShown')) {
            $('#myModal').modal('show');
            localStorage.setItem('modelShown', true);
        }
    }

    validateForm(event){
        const validateFields = ['name', 'phone', 'city','message'];
        if (event.target.name == 'email') {
            if (validator.isEmail(event.target.value)) 
                this.setState({emailErr: false});
            else if (validator.isEmpty(event.target.value))
                this.setState({emailErr: 'Email should not be empty'});
            else
                this.setState({emailErr: 'Email is Invalid'});
        } else {
            validateFields.forEach(function(field){
                if (event.target.name == field) {
                    if (validator.isEmpty(event.target.value))
                        this.setState({[field + 'Err']: field.charAt(0).toUpperCase() + field.slice(1)+' should not be empty'});
                    else
                        this.setState({[field + 'Err']: false});
                }
            }.bind(this));
        }
    }

    handleChange(event) {
        this.setState({ [event.target.name]: event.target.value });
    }

    interestChange(data = []){
        if (data == null)
            data = [];
        let newInterest = [];
        data.forEach(function(val, key){
            newInterest.push(val.value);
        });
        this.setState({
            interest: newInterest
        });
        if (this.state.interest.length == 0) {
            this.setState({
                interestErr: 'Atleast select one interest'
            });
        } else {
            this.setState({
                interestErr: false
            });
        }
    }

    handleSubmit(event) {
        event.preventDefault();
        if (this.state.interest.length == 0) {
            this.setState({
                interestErr: 'Atleast select one interest'
            });
            return;
        } else {
            this.setState({
                interestErr: false
            });
        }
        if (this.state.emailErr === false && this.state.nameErr === false && this.state.phoneErr === false && this.state.cityErr === false && this.state.messageErr === false){ //use || for more Err validations
            const formData = this.state;
            axios({
                method: 'post',
                url: config.ROUTE_URL+'/contact',
                params: formData/*,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }*/
            }).then(res => {
                if (res.data.status)
                    toast.success("Successfully submitted", {
                        position: "top-center",
                        autoClose: 1400,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true
                    });
            }).catch(error => {
                Object.values(error.response.data.errors).forEach(function(val){
                    document.getElementById('errors').innerHTML = '<p>'+val+'</p>';
                }.bind(this));
            })

        } else {
            var elements = document.getElementsByTagName('input');
            // for (var i = 0; i < elements.length; i++) {
            //     console.log(i);
            //     // elements[i].focus();elements[i].blur();
            // }​
            toast.error("Validation Error", {
                position: "top-center",
                autoClose: false,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true
            });
            return;
        }
    }
    
    modalValidateForm(){
        if (validator.isEmail(event.target.value)) 
                this.setState({modalemailErr: false});
            else if (validator.isEmpty(event.target.value))
                this.setState({modalemailErr: 'Email should not be empty'});
            else
                this.setState({modalemailErr: 'Email is Invalid'});
    }

    modalHandleSubmit(event){
        event.preventDefault();
        if (this.state.modalemailErr == false) {
            let formData = {email: this.state.modalemail};
            axios({
                method: 'post',
                url: config.ROUTE_URL+'/join-us',
                params: formData
            }).then(res => {
                if (res.data.status) {
                    $('#myModal').modal('hide');
                    toast.success("Successfully submitted", {
                        position: "top-center",
                        autoClose: 1400,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true
                    });
                }
            }).catch(error => {
                Object.values(error.response.data.errors).forEach(function(val){
                    document.getElementById('modal-errors').innerHTML = '<p>'+val+'</p>';
                }.bind(this));
            })
        } else{
            toast.error("Validation Error", {
                position: "top-center",
                autoClose: false,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true
            });
            return;
        }
    }

    render() {
        const hmBanners = {
            dots: true,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000
        };
        const hmClients = {
            dots: false,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000
        };
        const hmTesti = {
            dots: false,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000
        };
        const interestOptions = [
          { value: 'responsive', label: 'Responsive' },
          { value: 'eCommerce', label: 'E-Commerce' },
          { value: 'digitalMarketing', label: 'Digital Marketing' },
          { value: 'socialMedia', label: 'Social Media' },
          { value: 'seo', label: 'SEO' },
          { value: 'goodleAds', label: 'Goodle Ads' },
          { value: 'videoContent', label: 'Video Content' },
          { value: 'strategic', label: 'Strategic' }
        ];

        const interestStyles = {
            multiValue: (base, state) => {
                return state.data.isFixed ? { ...base, backgroundColor: 'gray' } : base;
            },
            multiValueLabel: (base, state) => {
                return state.data.isFixed
              ? { ...base, fontWeight: 'bold', color: 'white', paddingRight: 6 }
              : base;
            },
            multiValueRemove: (base, state) => {
                return state.data.isFixed ? { ...base, display: 'none' } : base;
            },
        };
        return (
            <React.Fragment>
                <MetaTags>
                    <title>Digital Marketing Agency | Web design company | Social Media | SEO Services Chennai, Mumbai, Pune and Bangalore, India</title>
                    <meta name="description" content="Bleap is a full-service digital marketing agency specializing in responsive web design &amp; development, SEO, PPC, Social Media Marketing. We help clients big &amp; small in B2B, B2C, and eCommerce. We have offices in Chennai, Mumbai, Pune and Bangalore."/>
                    <link rel="canonical" href="https://www.bleap.in/" />
                    <meta property="og:locale" content="en_US" />
                    <meta property="og:type" content="website" />
                    <meta property="og:title" content="Digital Marketing Agency | Web design company | Social Media | SEO Services Chennai, Mumbai, Pune and Bangalore, India" />
                    <meta property="og:description" content="Bleap is a full-service digital marketing agency specializing in responsive web design &amp; development, SEO, PPC, Social Media Marketing. We help clients big &amp; small in B2B, B2C, and eCommerce. We have offices in Chennai, Mumbai, Pune and Bangalore." />
                    <meta property="og:url" content="https://www.bleap.in/" />
                    <meta property="og:site_name" content="BLeap" />
                    <meta name="twitter:card" content="summary_large_image" />
                    <meta name="twitter:description" content="Bleap is a full-service digital marketing agency specializing in responsive web design &amp; development, SEO, PPC, Social Media Marketing. We help clients big &amp; small in B2B, B2C, and eCommerce. We have offices in Chennai, Mumbai, Pune and Bangalore." />
                    <meta name="twitter:title" content="Digital Marketing Agency | Web design company | Social Media | SEO Services Chennai, Mumbai, Pune and Bangalore, India" />
                    <meta name="twitter:image" content="http://bleap.in/wp-content/uploads/2018/07/serv-web-design.jpg" />
                </MetaTags>
                <section className="banner-wrap">               
                        <Slider {...hmBanners}>
					<section className="banner banner1">
						<section className="container">
							<aside className="cnt">
								<h1>Website Design &amp; Digital Marketing Agency &#8211; Chennai, Mumbai, Pune &amp; Bangalore</h1>
								<section className="btn-wrap">
									<Link to={config.ROUTE_URL+'/about-us'} className="btn-primary">Explore More</Link>
								</section>
							</aside>
						</section>			
                    </section>
					<section className="banner banner2">
						<section className="container">
							<aside className="cnt">
								<h1>
									{
										{
											'ta': ('92% வலைத்தளங்கள் மொபைல் போன்களில் பார்க்கப்படுகின்றன.')
										} [localStorage.getItem('siteLang')] || '92% websites are viewed over mobile phones.'
									}
								</h1>
								<p>We are the <strong>experts</strong> in creating functionally brilliant web sites.</p>
								<section className="btn-wrap">
									<Link to={config.ROUTE_URL+'/services/responsive-website-design-development'} className="btn-primary">Explore More</Link>
								</section>
							</aside>
						</section>
                    <section className="bird"></section>
                    <section className="btm-bg btm-img"></section>		
                    </section>
						<section className="banner banner3">
						<section className="container">
							<aside className="cnt">
								<h1>We are the leaders in designing Smart Websites (Progressive Web Apps).</h1>
								<p>Convenience of browser based launching &amp; functionality of a native App at 50% the cost.</p>
								<section className="btn-wrap">
									<Link to={config.ROUTE_URL+'/services/online-advertising'} className="btn-primary">Explore More</Link>
								</section>
							</aside>
						</section>			
                    </section>
				<section className="banner banner4">
						<section className="container">
							<aside className="cnt">
								<h1>Our SEO campaigns can grow organic traffic by upto 50% in 6 months.</h1>
								<p>More traffic means more business. Simple.</p>
								<section className="btn-wrap">
									<Link to={config.ROUTE_URL+'/services/search-engine-optimization'} className="btn-primary">Explore More</Link>
								</section>
							</aside>
						</section>			
                    </section>
									
                      </Slider>
                </section>
                <section className="intro section-wrap">
                    <section className="container">
                        <aside className="cnt">
                            <h2>BLeap</h2>
                            <h3>Website Design & Digital Marketing Company Chennai, Mumbai, Pune & Bangalore</h3>
                            <p>Bleap Integrated Marketing Solutions is a full service website design & digital marketing agency with offices located in Chennai, Mumbai, Pune and Bangalore. We provide Online services like Website design & development, Search Engine Optimization (SEO)</p>
                            <section className="btn-wrap">
                    			<Link to={config.ROUTE_URL+'/about-us'} className="btn-primary">Read More</Link>
							</section>
                        </aside>
                    </section>
                    <section className="btm-bg btm-img"></section>
                </section>
                <section className="our-website-design section-wrap">
                    <section className="top-bg top-img"></section>
                    <section className="btm-bg btm-img"></section>
                    <section className="container">
                    <h2>Our Website Design & Digital Marketing Services</h2>
                    <section className="row">
                        <section className="col-md-4 col-sm-6 col-12">
                            <section className="item">
                                <figure><img src={config.ROUTE_URL+"/public/home/images/website-design.png"} alt="Website Design" className="img-responsive" /></figure>
                                <h3>Website Design & Development</h3>
                                <p>Mobile responsive website design, PHP, Word Press, .Net based corporate websites…</p>
                                <section className="btn-wrap">
                                	<Link to={config.ROUTE_URL+'/services/responsive-website-design-development'} className="btn-primary">Read More</Link>
                                </section>
                            </section>
                        </section>
                        <section className="col-md-4 col-sm-6 col-12">
                            <section className="item">
                                <figure><img src={config.ROUTE_URL+"/public/home/images/seo.png"} alt="SEO" className="img-responsive" /></figure>
                                <h3>Search Engine Optimization</h3>
                                <p>Search Engine Optimization or SEO is the foundation of any digital business. SEO brings visitors...</p>
                                <section className="btn-wrap">
                                	<Link to={config.ROUTE_URL+'/services/search-engine-optimization'} className="btn-primary">Read More</Link>
                                </section>
                            </section>
                        </section>
                        <section className="col-md-4 col-sm-6 col-12">
                            <section className="item">
                                <figure><img src={config.ROUTE_URL+"/public/home/images/digital-marketing.png"} alt="Digital Marketing" className="img-responsive" /></figure>
                                <h3>Digital Marketing</h3>
                                <p>Search Engine Optimization or SEO is the foundation of any digital business. SEO brings visitors...</p>
                                <section className="btn-wrap">
                                	<Link to={config.ROUTE_URL+'/services/online-advertising'} className="btn-primary">Read More</Link>
                                </section>
                            </section>
                        </section>
                        <section className="col-md-4 col-sm-6 col-12">
                            <section className="item">
                                <figure><img src={config.ROUTE_URL+"/public/home/images/ecommerce-website.png"} alt="Ecommerce Website" className="img-responsive" /></figure>
                                <h3>E-Commerce Websites</h3>
                                <p>Mobile responsive website design, PHP, Word Press, .Net based corporate websites…</p>
                                <section className="btn-wrap">
                                	<Link to={config.ROUTE_URL+'/services/ecommerce-solutions'} className="btn-primary">Read More</Link>
                                </section>
                            </section>
                        </section>
                        <section className="col-md-4 col-sm-6 col-12">
                            <section className="item">
                                <figure><img src={config.ROUTE_URL+"/public/home/images/social-media-marketing.png"} alt="SMM" className="img-responsive" /></figure>
                                <h3>Social Media Marketing</h3>
                                <p>Search Engine Optimization or SEO is the foundation of any digital business. SEO brings visitors...</p>
                                <section className="btn-wrap">
                                	<Link to={config.ROUTE_URL+'/services/online-advertising/social-media-marketing'} className="btn-primary">Read More</Link>
                                </section>
                            </section>
                        </section>
                        <section className="col-md-4 col-sm-6 col-12">
                            <section className="item">
                                <figure><img src={config.ROUTE_URL+"/public/home/images/website-redesign.png"} alt="Website Redesign" className="img-responsive" /></figure>
                                <h3>Wesbite Redesigning Services</h3>
                                <p>Search Engine Optimization or SEO is the foundation of any digital business. SEO brings visitors...</p>
                                <section className="btn-wrap">
                                	<Link to={config.ROUTE_URL+'/services/responsive-website-design-development'} className="btn-primary">Read More</Link>
                                </section>
                            </section>
                        </section>
                    </section>
                    </section>
                </section>
				<section className="hm-testi">
                    <section className="top-bg top-img"></section>
                    <section className="container">
                        <h2 className="bird">Testimonial</h2>
                        <h3>Check what's our client Say about us</h3>			
						<section className="testi-slider">	
                        <Slider {...hmTesti}>
                        <div className="item-wrap">
							<section className="item-desc">
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus.</p>
							</section>
							<section className="author">
							Priya Scahdev<span>CEO & Founder RocknShop.com</span>
							</section>
                        </div>
                        <div className="item-wrap">
							<section className="item-desc">
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus.</p>
							</section>
							<section className="author">
							Priya Scahdev<span>CEO & Founder RocknShop.com</span>
							</section>
                        </div>
                      </Slider>
					</section>
					</section>
                    <section className="btm-bg left"></section>
				</section>
                <section className="our-clients section-wrap">
                    <section className="container">
                        <h2>Our Clients</h2>
                        <h3>Some of OUR Valuable and happy CLIENTS are</h3>  
                            <section className="clients-slider">                     
                        <Slider {...hmClients}>
                            <div>
                                <ul>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/rane.png"} alt="Rane" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/rock-n-shop.png"} alt="Rock N Shop" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/kriyatec.png"} alt="Kriyatec" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/osian-chlorophyll.png"} alt="Osian Chlorophyll" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/done-partners.png"} alt="Done Partners" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/sathya.png"} alt="Sathya" className="img-responsive" /></figure></li>
                                </ul>
                            </div>
                            <div>
                                <ul>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/rane.png"} alt="Rane" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/rock-n-shop.png"} alt="Rock N Shop" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/kriyatec.png"} alt="Kriyatec" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/osian-chlorophyll.png"} alt="Osian Chlorophyll" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/done-partners.png"} alt="Done Partners" className="img-responsive" /></figure></li>
                                    <li><figure><img src={config.ROUTE_URL+"/public/home/images/client-logos/sathya.png"} alt="Sathya" className="img-responsive" /></figure></li>
                                </ul>
                            </div>
                      </Slider>
                            </section>
                    </section>
                    </section>
                    <section className="enquire-now section-wrap">
						<aside className="btm-bg btm-img"></aside>
                        <section className="container">
                            <section className="row">
                                <section className="contact-form-section col-md-6 col-sm-12" style={{padding: '10px'}}>
                                    <section className="form">
                                        <h3>Enquire Now</h3>
                                        <form onSubmit={this.handleSubmit} noValidate>
                                            <div className={(this.state.nameErr) ? 'has-error form-group' : 'form-group'}>
                                                <input id="name" type="text" className="form-control border-bottom inputText" name="name" value={this.state.name} onBlur={this.validateForm} required autoComplete="name" onChange={this.handleChange} placeholder="Name*" />
                                                {this.state.nameErr && <p className="help-block bg-white">{this.state.nameErr}</p> }
                                            </div>
                                            <div className={(this.state.phoneErr) ? 'has-error form-group' : 'form-group'}>
                                                <input id="phne" type="text" className="form-control border-bottom inputText" name="phone" value={this.state.phone} onBlur={this.validateForm} onChange={this.handleChange} required autoComplete="phone" placeholder="Phone No*" />
                                                {this.state.phoneErr && <p className="help-block bg-white">{this.state.phoneErr}</p> }
                                            </div>
                                            <div className={(this.state.emailErr) ? 'has-error form-group' : 'form-group'}>
                                                <input id="email" type="email" className="form-control border-bottom inputText" name="email" value={this.state.email} onChange={this.handleChange} onBlur={this.validateForm} required autoComplete="email" placeholder="Email Id*" />
                                                {this.state.emailErr && <p className="help-block bg-white">{this.state.emailErr}</p> }
                                            </div>
                                            <div className={(this.state.cityErr) ? 'has-error form-group' : 'form-group'}>
                                                <input id="city" type="text" className="form-control border-bottom inputText" name="city" value={this.state.city} onBlur={this.validateForm} onChange={this.handleChange} required autoComplete="city" placeholder="City*" />
                                                {this.state.cityErr && <p className="help-block bg-white">{this.state.cityErr}</p> }
                                            </div>
                                            <div className="form-group">
                                                <Select
                                                    name="interest"
                                                    onChange={this.interestChange}
                                                    isMulti
                                                    name="colors"
                                                    options={interestOptions}
                                                    className="sel-control"
                                                    classNamePrefix="select"
                                                />
                                                {this.state.interestErr && <p className="help-block bg-white">{this.state.interestErr}</p> }
                                            </div>
                                            <div className={(this.state.messageErr) ? 'has-error form-group' : 'form-group'}>
                                                <textarea id="message"className="form-control border-bottom inputText" name="message" value={this.state.message} onBlur={this.validateForm} onChange={this.handleChange} required placeholder="your message..."></textarea>
                                                {this.state.messageErr && <p className="help-block bg-white">{this.state.messageErr}</p> }
                                            </div>
                                            <div className="form-group mb-0">
                                                <div className="col-md-8">
                                                    <button type="submit" className="btn btn-primary" style={{border: '2px solid #FFF', background: 'none'}}>
                                                        Send Now
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </section>
                                </section>
                                <section className="col-md-6 col-sm-12">
                                    <section className="digital-gyan">
                                     <h3>Digital Gyan</h3>
                                        <section className="item-cont clearfix">
                                            <figure><img src={config.ROUTE_URL+"/public/home/images/digital-gyan.jpg"} alt="Digital Gyan" className="img-responsive" /></figure>
                                            <section className="item-desc">
                                                <h4>6 QUESTIONS TO ASK A RESTAURANT MARKETING AGENCY BEFORE SIGN UP</h4>
                                                <p>When you own a restaurant, you know. You’ve spent your hard earned earnings and umpteen hours of hard work to put it up together. However, when it comes to marketing, most restaurateurs are confused what to do?</p>
												<section className="btn-wrap">
												<a href="https://www.bleap.in/2018/07/10/6-questions-to-ask-a-restaurant-marketing-agency-before-sign-up/" className="btn-primary">Read More</a>
												</section>
											</section>
                                        </section>
                                        
                                    </section>
                                </section>
                            </section>
                        </section>
                    </section>
					<section className="congrats-blk section-wrap">
						<section className="container">
							<h2>Congrats!</h2>
							<p>Your search for the best Digital Marketing Partner concludes successfully. Bleap Integrated Marketing is the best digital marketing agency with offices in 
							{/*<a href="javascript:;">Bangalore, Chennai, Mumbai</a> 
							and <a href="javascript:;">Pune</a>. */}
							<Link to={config.ROUTE_URL+"/contact-us/digital-marketing-agency-in-bangalore/"}>Bangalore,</Link>
							<Link to={config.ROUTE_URL+"/contact-us/digital-marketing-agency-in-chennai/"}>Chennai,</Link>
							<Link to={config.ROUTE_URL+"/contact-us/digital-marketing-agency-in-mumbai/"}>Mumbai,</Link>
							<Link to={config.ROUTE_URL+"/contact-us/digital-marketing-agency-in-pune/"}>Pune</Link>
							<a href="javascript:;">We provide online services</a> such as 
							
							<Link to={config.ROUTE_URL+'/services/responsive-website-design-development'}>Responsive Web Design & Development,</Link>
							<Link to={config.ROUTE_URL+'/services/search-engine-optimization'}>Search Engine Optimization (SEO),</Link>
							 <Link to={config.ROUTE_URL+'/services/online-advertising'} >Search Engine Marketing (SEM), </Link>
							 <Link to= {config.ROUTE_URL+'/services/online-advertising/social-media-marketing'}>Social Media Marketing (SMM), </Link>
							 Social Media Optimization (SMO), 
							 e-Commerce Websites, Content Marketing, Online Reputation Management, Website Localization and
							  <Link to= {config.ROUTE_URL+'/services/strategic-marketing'}>Strategic Marketing Services</Link>
							  to clients from India and across the world. Financial Services, Real Estate, e-commerce, Jewellery Retail, Automotive and Healthcare are our key focus areas. We have worked with many start-ups from all over to kick start their digital marketing journey and given excellent ROI for their investment. We manage more than 74 clients from India, UAE, Australia, New Zealand, US and UK. We are a preferred partner for Google, Facebook, Instagram, SnapChat, LinkedIn and Twitter</p>
						</section>
						<section className="btm-bg btm-img"></section>
					</section>
                    <Footer />
                {/*Modal starts*/}
                <div id="myModal" className="modal fade" role="dialog">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <center><h4 className="modal-title"><b>Join the community.</b></h4></center>
                                <button type="button" className="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div className="modal-body">
                                <div className="row text-danger" id="modal-errors"></div>
                                <center><p>Sign up now and receive our news</p></center>
                                <form onSubmit={this.modalHandleSubmit} noValidate>
                                    <div className={(this.state.modelemailErr) ? 'has-error form-group row' : 'form-group row'}>
                                        <label htmlFor="email" className="col-md-4 col-form-label text-md-right required">E-Mail Address :</label>

                                        <div className="col-md-8">
                                            <input id="modal-email" type="email" className="form-control" name="modalemail" value={this.state.modalemail} onChange={this.handleChange} onBlur={this.modalValidateForm} required autoComplete="email" />
                                        </div>
                                        {this.state.modalemailErr && <p className="help-block">{this.state.modalemailErr}</p> }
                                    </div>
                                    <div className="form-group row mb-0">
                                        <div className="col-md-8 offset-md-4">
                                            <button type="submit" className="btn btn-primary">
                                                Subscribe
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                {/*Modal ends*/}
            </React.Fragment>
        );
    }
}


export default Home;
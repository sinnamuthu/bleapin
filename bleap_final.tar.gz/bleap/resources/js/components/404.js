import React, { Component } from 'react';
import config from './Config';

class NotFound extends Component {
    render() {
        return (
            <section className="sub-page notfound">
                <section className="container">
                   {/* <center><h1>404 Not Found</h1></center>*/}
                    <center>
                        <figure><img src={config.ROUTE_URL+"/public/home/images/notfound.png"} alt="Not Found" className="img-responsive" /></figure>
                    </center>
                </section>
            </section>
        );
    }
}
export default NotFound;